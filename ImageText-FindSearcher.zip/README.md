# ImageText FindSearcher

An Android app that finds words inside your pictures — for example, screenshots of Facebook posts, chats or web pages.

## Features
- Choose one or more picture folders to search.
- Search several words at once: **All words (AND)** or **Any word (OR)**; exact phrases in quotes.
- Case-insensitive, partial-word matching, optional accent-insensitive matching (é = e, š = s).
- Result list with thumbnail, full file path, creation date/time and a text snippet.
- Tap a result to see the image with **frames around the matched words**; long screenshots jump to the first match.
- Progress bar and **Cancel** button while searching.
- Export: copy to clipboard or save as CSV.
- Recognized text is saved inside the app, so repeat searches are almost instant.

## Privacy and safety
- Read-only access to pictures — the app cannot change, move or delete files.
- **No internet permission** — nothing leaves the phone.
- Text recognition runs on the device (Google ML Kit).

## Build
GitHub Actions (`.github/workflows/build.yml`) runs `gradle assembleRelease`.
The APK is signed with `app/signing.p12`; its password is provided by the repository secret `SIGNING_PASSWORD`.
