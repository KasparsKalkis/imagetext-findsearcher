plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// The signing key file (signing.p12) is protected by a password that is NOT stored
// in the code. GitHub Actions passes it in from the repository secret SIGNING_PASSWORD.
val signingPassword: String? = System.getenv("SIGNING_PASSWORD")?.takeIf { it.isNotBlank() }

android {
    namespace = "io.github.kasparskalkis.imagetext"
    compileSdk = 34

    defaultConfig {
        applicationId = "io.github.kasparskalkis.imagetext"
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        ndk {
            abiFilters += listOf("arm64-v8a")
        }
    }

    signingConfigs {
        create("release") {
            storeFile = file("signing.p12")
            storeType = "PKCS12"
            storePassword = signingPassword ?: ""
            keyAlias = "imagetext"
            keyPassword = signingPassword ?: ""
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            if (signingPassword != null) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.activity:activity-compose:1.8.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.7.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")

    implementation(platform("androidx.compose:compose-bom:2024.02.02"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")

    // On-device text recognition (works offline)
    implementation("com.google.mlkit:text-recognition:16.0.1")
}
