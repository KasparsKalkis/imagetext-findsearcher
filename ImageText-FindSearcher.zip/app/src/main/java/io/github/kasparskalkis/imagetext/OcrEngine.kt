package io.github.kasparskalkis.imagetext

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapRegionDecoder
import android.graphics.Rect
import android.net.Uri
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Text recognition with Google ML Kit (runs on the phone, offline).
 * The image is only READ into memory; the file is never changed.
 * Long "scroll capture" screenshots are processed in strips to avoid running out of memory.
 * Word positions are returned in original image pixels.
 * Call ONLY from a background thread.
 */
class OcrEngine {

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    fun close() {
        try {
            recognizer.close()
        } catch (_: Throwable) {
        }
    }

    fun read(ctx: Context, uri: Uri): OcrData {
        val cr = ctx.contentResolver

        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        val s1 = cr.openInputStream(uri) ?: throw IOException("Cannot open file")
        s1.use { BitmapFactory.decodeStream(it, null, bounds) }
        val w = bounds.outWidth
        val h = bounds.outHeight
        if (w <= 0 || h <= 0) throw IOException("Not a readable image")

        var sample = 1
        while (w / sample > MAX_WIDTH) sample *= 2
        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }

        if (h / sample <= MAX_SINGLE_HEIGHT) {
            val s2 = cr.openInputStream(uri) ?: throw IOException("Cannot open file")
            val bmp = s2.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: throw IOException("Could not decode image")
            try {
                return OcrData(w, h, recognize(bmp, sample, 0, Int.MIN_VALUE, Int.MAX_VALUE))
            } finally {
                bmp.recycle()
            }
        }

        // Long image: process in strips with a small overlap.
        // Each text line is kept only in the strip where its vertical center lies,
        // so lines in the overlap are not duplicated.
        val lines = ArrayList<OcrLine>()
        val s3 = cr.openInputStream(uri) ?: throw IOException("Cannot open file")
        s3.use { input ->
            @Suppress("DEPRECATION")
            val decoder = BitmapRegionDecoder.newInstance(input, false)
                ?: throw IOException("Could not decode image")
            try {
                val stripH = STRIP_HEIGHT * sample
                val overlap = OVERLAP * sample
                var top = 0
                while (top < h) {
                    val bottom = minOf(h, top + stripH)
                    val lo = if (top == 0) Int.MIN_VALUE else top + overlap / 2
                    val hi = if (bottom >= h) Int.MAX_VALUE else bottom - overlap / 2
                    val bmp = decoder.decodeRegion(Rect(0, top, w, bottom), opts)
                    if (bmp != null) {
                        try {
                            lines.addAll(recognize(bmp, sample, top, lo, hi))
                        } finally {
                            bmp.recycle()
                        }
                    }
                    if (bottom >= h) break
                    top = bottom - overlap
                }
            } finally {
                decoder.recycle()
            }
        }
        return OcrData(w, h, lines)
    }

    private fun recognize(bmp: Bitmap, sample: Int, offsetY: Int, lo: Int, hi: Int): List<OcrLine> {
        val image = InputImage.fromBitmap(bmp, 0)
        // Time limit: a single image can never freeze the search.
        val result = Tasks.await(recognizer.process(image), 30, TimeUnit.SECONDS)
        val out = ArrayList<OcrLine>()
        for (block in result.textBlocks) {
            for (line in block.lines) {
                val words = ArrayList<OcrWord>()
                for (el in line.elements) {
                    val r = el.boundingBox ?: continue
                    val text = el.text.trim()
                    if (text.isEmpty()) continue
                    words.add(
                        OcrWord(
                            text,
                            Box(
                                r.left * sample,
                                r.top * sample + offsetY,
                                r.right * sample,
                                r.bottom * sample + offsetY,
                            ),
                        )
                    )
                }
                if (words.isEmpty()) continue
                val centerY = (words.minOf { it.box.top } + words.maxOf { it.box.bottom }) / 2
                if (centerY < lo || centerY >= hi) continue
                out.add(OcrLine(words))
            }
        }
        return out
    }

    companion object {
        private const val MAX_WIDTH = 2200
        private const val MAX_SINGLE_HEIGHT = 4000
        private const val STRIP_HEIGHT = 2500
        private const val OVERLAP = 150
    }
}
