package io.github.kasparskalkis.imagetext

import android.content.ContentUris
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.provider.BaseColumns
import android.provider.MediaStore

data class Folder(
    val bucketId: Long,
    val name: String,
    val path: String,
    val count: Int,
)

data class ImageItem(
    val id: Long,
    val uri: Uri,
    val name: String,
    val fullPath: String,
    val folder: String,
    val createdMillis: Long,
    val modifiedSec: Long,
    val size: Long,
)

/**
 * Reads the list of images from the Android media database.
 * ONLY query() is used here — nothing is ever written, deleted or moved.
 */
object MediaRepo {

    private val collection: Uri
        get() = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)

    private class Acc(val name: String, val path: String, var count: Int)

    fun loadFolders(ctx: Context): List<Folder> {
        val proj = arrayOf(
            MediaStore.MediaColumns.BUCKET_ID,
            MediaStore.MediaColumns.BUCKET_DISPLAY_NAME,
            MediaStore.MediaColumns.RELATIVE_PATH,
            MediaStore.MediaColumns.VOLUME_NAME,
        )
        val map = LinkedHashMap<Long, Acc>()
        ctx.contentResolver.query(collection, proj, null, null, null)?.use { c ->
            val iB = c.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_ID)
            val iN = c.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME)
            val iP = c.getColumnIndexOrThrow(MediaStore.MediaColumns.RELATIVE_PATH)
            val iV = c.getColumnIndexOrThrow(MediaStore.MediaColumns.VOLUME_NAME)
            while (c.moveToNext()) {
                val id = c.getLong(iB)
                val acc = map[id]
                if (acc != null) {
                    acc.count++
                } else {
                    val name = c.str(iN) ?: "(no name)"
                    val rel = c.str(iP) ?: ""
                    val vol = c.str(iV) ?: ""
                    val path = if (vol.isEmpty() || vol == MediaStore.VOLUME_EXTERNAL_PRIMARY) rel else "SD card: $rel"
                    map[id] = Acc(name, path, 1)
                }
            }
        }
        return map.map { (id, a) -> Folder(id, a.name, a.path, a.count) }
            .sortedBy { it.name.lowercase() }
    }

    fun loadImages(ctx: Context, bucketIds: Set<Long>): List<ImageItem> {
        if (bucketIds.isEmpty()) return emptyList()
        val proj = arrayOf(
            BaseColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.BUCKET_DISPLAY_NAME,
            MediaStore.MediaColumns.RELATIVE_PATH,
            MediaStore.MediaColumns.DATA,
            MediaStore.MediaColumns.DATE_TAKEN,
            MediaStore.MediaColumns.DATE_ADDED,
            MediaStore.MediaColumns.DATE_MODIFIED,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.VOLUME_NAME,
        )
        val ids = bucketIds.toList()
        val selection = "${MediaStore.MediaColumns.BUCKET_ID} IN (${ids.joinToString(",") { "?" }})"
        val args = ids.map { it.toString() }.toTypedArray()
        val sort = "${MediaStore.MediaColumns.DATE_ADDED} DESC"

        val out = ArrayList<ImageItem>()
        ctx.contentResolver.query(collection, proj, selection, args, sort)?.use { c ->
            val iId = c.getColumnIndexOrThrow(BaseColumns._ID)
            val iName = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            val iBucket = c.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME)
            val iRel = c.getColumnIndexOrThrow(MediaStore.MediaColumns.RELATIVE_PATH)
            val iData = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA)
            val iTaken = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN)
            val iAdded = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
            val iMod = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED)
            val iSize = c.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
            val iVol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.VOLUME_NAME)
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                val name = c.str(iName) ?: "?"
                val vol = c.str(iVol) ?: MediaStore.VOLUME_EXTERNAL_PRIMARY
                val data = c.str(iData)
                val rel = c.str(iRel) ?: ""
                val fullPath = if (!data.isNullOrBlank()) data else "/storage/emulated/0/$rel$name"
                val taken = if (c.isNull(iTaken)) 0L else c.getLong(iTaken)
                val added = if (c.isNull(iAdded)) 0L else c.getLong(iAdded) * 1000L
                out.add(
                    ImageItem(
                        id = id,
                        uri = ContentUris.withAppendedId(MediaStore.Images.Media.getContentUri(vol), id),
                        name = name,
                        fullPath = fullPath,
                        folder = c.str(iBucket) ?: "",
                        createdMillis = if (taken > 0) taken else added,
                        modifiedSec = if (c.isNull(iMod)) 0L else c.getLong(iMod),
                        size = if (c.isNull(iSize)) 0L else c.getLong(iSize),
                    )
                )
            }
        }
        return out
    }

    private fun Cursor.str(i: Int): String? = if (isNull(i)) null else getString(i)
}
