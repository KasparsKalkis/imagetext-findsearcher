@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package io.github.kasparskalkis.imagetext

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.util.Size
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun MainScreen(vm: MainViewModel) {
    val context = LocalContext.current
    val view = LocalView.current

    // State kept while switching between the list and the image viewer
    val listState = rememberLazyListState()
    val foldersExpanded = rememberSaveable { mutableStateOf(false) }
    var showHelp by rememberSaveable { mutableStateOf(false) }

    // Short messages (Toast)
    LaunchedEffect(vm.message) {
        val m = vm.message
        if (m != null) {
            Toast.makeText(context, m, Toast.LENGTH_SHORT).show()
            vm.consumeMessage()
        }
    }

    // Keep the screen on while searching
    DisposableEffect(vm.scanning) {
        view.keepScreenOn = vm.scanning
        onDispose { view.keepScreenOn = false }
    }

    val viewing = vm.viewing
    if (viewing != null) {
        ImageViewer(
            item = viewing,
            onClose = { vm.viewing = null },
            onOpenInGallery = { openInGallery(context, viewing.uri, vm) },
        )
    } else {
        MainContent(vm, listState, foldersExpanded, onHelp = { showHelp = true })
    }

    if (showHelp) {
        HelpDialog(onClose = { showHelp = false })
    }
}

@Composable
private fun MainContent(
    vm: MainViewModel,
    listState: LazyListState,
    foldersExpanded: MutableState<Boolean>,
    onHelp: () -> Unit,
) {
    val context = LocalContext.current
    val focus = LocalFocusManager.current
    var confirmClear by remember { mutableStateOf(false) }

    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { vm.refresh() }

    val csvLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/csv")
    ) { uri -> if (uri != null) vm.exportCsv(uri) }

    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item(key = "title") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("ImageText FindSearcher", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
                    Text(
                        "Find words inside your pictures. Files are never changed; no internet is used.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Spacer(Modifier.width(8.dp))
                HelpButton(onHelp)
            }
        }

        if (!vm.hasPermission) {
            item(key = "perm") {
                PermissionCard(
                    onAllow = { permLauncher.launch(vm.permissionName) },
                    onSettings = { openAppSettings(context) },
                )
            }
            return@LazyColumn
        }

        item(key = "folders") {
            FolderCard(
                vm = vm,
                expanded = foldersExpanded.value,
                onToggleExpanded = { foldersExpanded.value = !foldersExpanded.value },
            )
        }

        item(key = "search") {
            SearchCard(
                vm = vm,
                onSearch = {
                    focus.clearFocus()
                    foldersExpanded.value = false
                    vm.startSearch()
                },
            )
        }

        if (vm.scanning) {
            item(key = "progress") { ProgressCard(vm) }
        } else if (vm.statusText.isNotEmpty()) {
            item(key = "status") {
                Text(vm.statusText, style = MaterialTheme.typography.bodyMedium)
            }
        }

        if (vm.results.isNotEmpty()) {
            item(key = "resultsHeader") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Results: ${vm.results.size}",
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.weight(1f),
                    )
                    TextButton(onClick = { vm.copyToClipboard() }, enabled = !vm.scanning) {
                        Text("Copy")
                    }
                    TextButton(onClick = { csvLauncher.launch(csvFileName()) }, enabled = !vm.scanning) {
                        Text("Save CSV")
                    }
                }
            }
            items(vm.results, key = { "r" + it.id }) { r ->
                ResultRow(r, onClick = { vm.viewing = r })
            }
        } else if (!vm.scanning && vm.lastSearchCompleted) {
            item(key = "empty") {
                Text(
                    "Nothing found. Try part of a word or the “Any word (OR)” mode.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        item(key = "footer") {
            Column(Modifier.padding(top = 8.dp)) {
                HorizontalDivider()
                Spacer(Modifier.height(8.dp))
                Text(
                    "Recognized text saved for ${vm.cachedCount} images — searching them again is instant.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                TextButton(onClick = { confirmClear = true }, enabled = !vm.scanning && vm.cachedCount > 0) {
                    Text("Delete saved text")
                }
            }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Delete saved text?") },
            text = {
                Text("Only the app's internal list of recognized text is deleted. Your pictures are not touched. The next search will be slower because the text has to be read again.")
            },
            confirmButton = {
                TextButton(onClick = { confirmClear = false; vm.clearCache() }) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { confirmClear = false }) { Text("Cancel") }
            },
        )
    }
}

@Composable
private fun HelpButton(onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = CircleShape,
        border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary),
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier.size(40.dp),
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                "?",
                color = MaterialTheme.colorScheme.primary,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
            )
        }
    }
}

@Composable
private fun PermissionCard(onAllow: () -> Unit, onSettings: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Access to pictures needed", style = MaterialTheme.typography.titleMedium)
            Text(
                "The app only reads your pictures. When asked, choose “Allow all” (not “Select photos”), otherwise only some pictures can be searched.",
                style = MaterialTheme.typography.bodyMedium,
            )
            Button(onClick = onAllow, modifier = Modifier.fillMaxWidth()) { Text("Allow access to pictures") }
            OutlinedButton(onClick = onSettings, modifier = Modifier.fillMaxWidth()) {
                Text("Open app settings")
            }
        }
    }
}

@Composable
private fun FolderCard(vm: MainViewModel, expanded: Boolean, onToggleExpanded: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth().clickable(enabled = !vm.scanning) { onToggleExpanded() },
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Folders", style = MaterialTheme.typography.titleMedium)
                    val selectedNames = vm.folders.filter { it.bucketId in vm.selectedIds }.map { it.name }
                    Text(
                        when {
                            vm.foldersLoading -> "Loading…"
                            selectedNames.isEmpty() -> "No folder selected"
                            else -> selectedNames.joinToString(", ") + " · ${vm.selectedImageCount} images"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                TextButton(onClick = onToggleExpanded, enabled = !vm.scanning) {
                    Text(if (expanded) "Done" else "Change")
                }
            }

            if (expanded && !vm.scanning) {
                Spacer(Modifier.height(8.dp))
                Row {
                    TextButton(onClick = { vm.selectAll() }) { Text("Select all") }
                    TextButton(onClick = { vm.selectNone() }) { Text("Clear all") }
                }
                if (vm.folders.isEmpty() && !vm.foldersLoading) {
                    Text("No picture folders found.", style = MaterialTheme.typography.bodyMedium)
                }
                for (f in vm.folders) {
                    val checked = f.bucketId in vm.selectedIds
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { vm.toggleFolder(f.bucketId) }
                            .padding(vertical = 2.dp),
                    ) {
                        Checkbox(checked = checked, onCheckedChange = { vm.toggleFolder(f.bucketId) })
                        Column(Modifier.weight(1f)) {
                            Text(f.name, style = MaterialTheme.typography.bodyLarge)
                            Text(
                                "${f.path} · ${f.count} images",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SearchCard(vm: MainViewModel, onSearch: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = vm.queryText,
                onValueChange = { vm.queryText = it },
                label = { Text("Words to find") },
                supportingText = { Text("Separate with spaces. For a phrase use quotes: \"city council\"") },
                singleLine = true,
                enabled = !vm.scanning,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { onSearch() }),
                modifier = Modifier.fillMaxWidth(),
            )

            Column(Modifier.selectableGroup()) {
                ModeOption("All words (AND)", vm.mode == MatchMode.ALL, !vm.scanning) { vm.mode = MatchMode.ALL }
                ModeOption("Any word (OR)", vm.mode == MatchMode.ANY, !vm.scanning) { vm.mode = MatchMode.ANY }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(enabled = !vm.scanning) { vm.ignoreAccents = !vm.ignoreAccents },
            ) {
                Checkbox(
                    checked = vm.ignoreAccents,
                    onCheckedChange = { vm.ignoreAccents = it },
                    enabled = !vm.scanning,
                )
                Text("Ignore accents (é = e, š = s)", style = MaterialTheme.typography.bodyMedium)
            }

            if (vm.scanning) {
                OutlinedButton(
                    onClick = { vm.cancel() },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                ) { Text("Cancel") }
            } else {
                Button(
                    onClick = onSearch,
                    enabled = vm.canSearch(),
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Search") }
            }
        }
    }
}

@Composable
private fun ModeOption(label: String, selected: Boolean, enabled: Boolean, onSelect: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .selectable(selected = selected, enabled = enabled, role = Role.RadioButton, onClick = onSelect),
    ) {
        RadioButton(selected = selected, onClick = null, enabled = enabled)
        Spacer(Modifier.width(12.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(vertical = 10.dp))
    }
}

@Composable
private fun ProgressCard(vm: MainViewModel) {
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (vm.total > 0) {
                val fraction = vm.done.toFloat() / vm.total.toFloat()
                LinearProgressIndicator(progress = { fraction }, modifier = Modifier.fillMaxWidth())
                Text(
                    "Checked ${vm.done} of ${vm.total} (${(fraction * 100).toInt()}%) · found ${vm.results.size}",
                    style = MaterialTheme.typography.bodyMedium,
                )
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(12.dp))
                    Text("Preparing…", style = MaterialTheme.typography.bodyMedium)
                }
            }
            Text(
                vm.currentName,
                style = MaterialTheme.typography.bodySmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                "The first search is slower (text has to be read). Later searches are fast.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun ResultRow(r: ResultItem, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable { onClick() }) {
        Row(Modifier.padding(12.dp)) {
            Thumb(r.uri)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    r.hit.fileName,
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    "Created: " + formatDate(r.hit.createdMillis),
                    style = MaterialTheme.typography.bodySmall,
                )
                Text(
                    r.hit.fullPath,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(
                    "Found: " + r.hit.matched.joinToString(", "),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                )
                if (r.hit.snippet.isNotBlank()) {
                    Text(
                        r.hit.snippet,
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
    }
}

@Composable
private fun Thumb(uri: Uri) {
    val context = LocalContext.current
    val bmp by produceState<ImageBitmap?>(initialValue = null, uri) {
        value = withContext(Dispatchers.IO) {
            try {
                context.contentResolver.loadThumbnail(uri, Size(192, 192), null).asImageBitmap()
            } catch (t: Throwable) {
                null
            }
        }
    }
    Box(
        Modifier
            .size(64.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
    ) {
        val b = bmp
        if (b != null) {
            Image(
                bitmap = b,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        }
    }
}

private fun formatDate(ms: Long): String =
    SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(ms))

private fun csvFileName(): String =
    "imagetext_search_" + SimpleDateFormat("yyyy-MM-dd_HHmm", Locale.US).format(Date()) + ".csv"

/** Opens the image in the gallery app for VIEWING only. */
private fun openInGallery(context: Context, uri: Uri, vm: MainViewModel) {
    val intent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(uri, "image/*")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    try {
        context.startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        vm.showMessage("No app found to open the image")
    }
}

private fun openAppSettings(context: Context) {
    val intent = Intent(
        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
        Uri.fromParts("package", context.packageName, null),
    )
    try {
        context.startActivity(intent)
    } catch (_: ActivityNotFoundException) {
    }
}
