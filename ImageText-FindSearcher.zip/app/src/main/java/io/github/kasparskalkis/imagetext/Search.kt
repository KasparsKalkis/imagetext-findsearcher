package io.github.kasparskalkis.imagetext

import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/** ALL = every word must be found (AND), ANY = at least one word (OR). */
enum class MatchMode { ALL, ANY }

data class Match(val terms: List<String>, val snippet: String)

/**
 * A search query.
 * Words are separated by spaces; a phrase can be put in quotes: "city council".
 * Case is ignored. With ignoreAccents = true, accented letters match plain ones (é = e, š = s).
 * Partial words match too: "hous" finds "houses".
 */
class SearchQuery(raw: String, val mode: MatchMode, val ignoreAccents: Boolean) {

    /** Pairs of (term as typed, normalized term). */
    private val pairs: List<Pair<String, String>> = parseTerms(raw)
        .map { it to normalize(it, ignoreAccents) }
        .filter { it.second.isNotBlank() }

    val terms: List<String> get() = pairs.map { it.first }
    val normalizedTerms: List<String> get() = pairs.map { it.second }
    val isEmpty: Boolean get() = pairs.isEmpty()

    fun match(text: String): Match? {
        if (pairs.isEmpty() || text.isEmpty()) return null
        val normText = normalize(text, ignoreAccents)
        var firstIdx = -1
        var firstLen = 0
        val found = ArrayList<String>()
        for ((orig, norm) in pairs) {
            val idx = normText.indexOf(norm)
            if (idx >= 0) {
                found.add(orig)
                if (firstIdx < 0 || idx < firstIdx) {
                    firstIdx = idx
                    firstLen = norm.length
                }
            }
        }
        val ok = when (mode) {
            MatchMode.ALL -> found.size == pairs.size
            MatchMode.ANY -> found.isNotEmpty()
        }
        if (!ok) return null
        return Match(found, snippet(text, firstIdx, firstLen))
    }

    companion object {
        private val termRegex = Regex("\"([^\"]+)\"|(\\S+)")
        private val spaces = Regex("\\s+")
        private val charCache = ConcurrentHashMap<Char, Char>()

        fun parseTerms(raw: String): List<String> {
            val unified = raw.replace('„', '"').replace('“', '"').replace('”', '"')
            return termRegex.findAll(unified)
                .map { m -> (m.groups[1]?.value ?: m.groups[2]?.value ?: "").trim().replace(spaces, " ") }
                .filter { it.isNotEmpty() && it != "\"" }
                .distinct()
                .toList()
        }

        /** Normalizes text while keeping exactly the same length (needed for snippets and highlights). */
        fun normalize(s: String, stripAccents: Boolean): String {
            val sb = StringBuilder(s.length)
            for (c in s) {
                val l = c.lowercaseChar()
                val out = when {
                    l.isWhitespace() -> ' '
                    stripAccents && l.code >= 128 -> stripChar(l)
                    else -> l
                }
                sb.append(out)
            }
            return sb.toString()
        }

        private fun stripChar(c: Char): Char = charCache.getOrPut(c) {
            if (Character.isSurrogate(c)) {
                c
            } else {
                val d = Normalizer.normalize(c.toString(), Normalizer.Form.NFD)
                if (d.isNotEmpty()) d[0] else c
            }
        }

        fun snippet(text: String, idx: Int, len: Int): String {
            if (idx < 0) return ""
            val start = maxOf(0, idx - 40)
            val end = minOf(text.length, idx + len + 60)
            val core = text.substring(start, end).replace(spaces, " ").trim()
            val pre = if (start > 0) "…" else ""
            val post = if (end < text.length) "…" else ""
            return pre + core + post
        }
    }
}

/** One found image — plain data used for display and export. */
data class Hit(
    val fullPath: String,
    val fileName: String,
    val folder: String,
    val createdMillis: Long,
    val matched: List<String>,
    val snippet: String,
)

object Export {
    fun formatDate(ms: Long): String =
        SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(ms))

    /** CSV separated by semicolons (opens correctly in European Excel and in Google Sheets). */
    fun csv(hits: List<Hit>): String {
        val sb = StringBuilder()
        sb.append("Full path;File name;Folder;Created;Matched words;Text snippet\r\n")
        for (h in hits) {
            sb.append(listOf(
                h.fullPath, h.fileName, h.folder, formatDate(h.createdMillis),
                h.matched.joinToString(", "), h.snippet,
            ).joinToString(";") { esc(it) })
            sb.append("\r\n")
        }
        return sb.toString()
    }

    /** Tab-separated text for the clipboard (pastes into Excel too). */
    fun clipboard(hits: List<Hit>): String {
        val sb = StringBuilder("Full path\tCreated\tMatched words\n")
        for (h in hits) {
            sb.append(h.fullPath.replace('\t', ' ')).append('\t')
                .append(formatDate(h.createdMillis)).append('\t')
                .append(h.matched.joinToString(", ")).append('\n')
        }
        return sb.toString()
    }

    private fun esc(s: String): String =
        if (s.any { it == ';' || it == '"' || it == '\n' || it == '\r' }) {
            "\"" + s.replace("\"", "\"\"") + "\""
        } else {
            s
        }
}
