package io.github.kasparskalkis.imagetext

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private val helpSections: List<Pair<String, String>> = listOf(
    "What this app does" to
        "ImageText FindSearcher finds words inside your pictures — for example, screenshots of Facebook posts, " +
        "chats or web pages. It reads the text that appears in each image and lists every image that contains " +
        "the words you are looking for, with its full file path and the date it was created.",

    "Folders" to
        "Choose which picture folders to search. Tap “Change” to tick one or more folders; " +
        "the number of images in each folder is shown. Screenshot folders are selected automatically the first time. " +
        "Your choice is remembered.",

    "Search words" to
        "Type one or more words separated by spaces. Upper/lower case does not matter. " +
        "Part of a word is enough: “hous” finds “house” and “houses”. " +
        "To search for an exact phrase, put it in quotes: \"city council\".",

    "All words (AND)" to
        "An image is listed only if it contains every word you typed.",

    "Any word (OR)" to
        "An image is listed if it contains at least one of the words. " +
        "The result shows which words were found.",

    "Ignore accents" to
        "When ticked, letters with accents match plain letters: “Rīga” = “riga”, “café” = “cafe”. " +
        "Untick it if you need an exact match.",

    "Search and Cancel" to
        "Tap “Search” to start. A progress bar shows how many images have been checked and how many matched. " +
        "Tap “Cancel” at any time — the results found so far stay on screen. " +
        "The screen stays on while searching.",

    "Results" to
        "Each result shows a thumbnail, the file name, the date and time it was created, the full path and a short " +
        "piece of the surrounding text. Tap a result to open the image with frames around the matched words. " +
        "Long screenshots scroll automatically to the first match. “Gallery” opens the picture in your gallery app " +
        "for zooming.",

    "Copy and Save CSV" to
        "“Copy” puts the list (path, date, matched words) on the clipboard — you can paste it into a message, " +
        "notes or Excel. “Save CSV” creates a spreadsheet file in a place you choose.",

    "Saved text — why later searches are fast" to
        "Reading text from an image takes a moment, so the first search through many images can take a few minutes. " +
        "The recognized text is saved inside the app, so the next searches in the same images are almost instant; " +
        "only new or changed images are read again. “Delete saved text” clears this list — your pictures are not " +
        "touched.",

    "Privacy and safety" to
        "• The app only READS your pictures. It cannot change, move or delete them.\n" +
        "• The app has no internet permission — nothing leaves your phone.\n" +
        "• Text recognition runs entirely on your phone.\n" +
        "• Damaged or unreadable files are skipped, and the count is shown at the end.",

    "Tips" to
        "• When asked for photo access, choose “Allow all”; with “Select photos” only the chosen photos can be searched.\n" +
        "• Handwriting and very small or blurry text may not be recognized.\n" +
        "• Latin-alphabet languages are supported (English, Latvian, German, French, etc.).",
)

@Composable
fun HelpDialog(onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Help") },
        text = {
            Column(
                modifier = Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                for ((title, body) in helpSections) {
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                        Text(body, style = MaterialTheme.typography.bodyMedium)
                    }
                }
                Text(
                    "ImageText FindSearcher " + BuildInfo.VERSION,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onClose) { Text("Close") }
        },
    )
}

object BuildInfo {
    const val VERSION = "1.0"
}
