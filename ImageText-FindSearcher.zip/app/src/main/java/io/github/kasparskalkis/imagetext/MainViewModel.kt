package io.github.kasparskalkis.imagetext

import android.Manifest
import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class ResultItem(
    val id: Long,
    val uri: Uri,
    val hit: Hit,
    val imageWidth: Int,
    val imageHeight: Int,
    val boxes: List<Box>,
)

private class Outcome(val item: ResultItem?, val error: Boolean)

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val cache = OcrCache(app)

    val permissionName: String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES
        else Manifest.permission.READ_EXTERNAL_STORAGE

    var hasPermission by mutableStateOf(false)
        private set
    var folders by mutableStateOf<List<Folder>>(emptyList())
        private set
    var foldersLoading by mutableStateOf(false)
        private set
    var selectedIds by mutableStateOf<Set<Long>>(emptySet())
        private set

    var queryText by mutableStateOf(prefs.getString("query", "") ?: "")
    var mode by mutableStateOf(
        if (prefs.getString("mode", "ALL") == "ANY") MatchMode.ANY else MatchMode.ALL
    )
    var ignoreAccents by mutableStateOf(prefs.getBoolean("accents", true))

    var scanning by mutableStateOf(false)
        private set
    var total by mutableIntStateOf(0)
        private set
    var done by mutableIntStateOf(0)
        private set
    var errors by mutableIntStateOf(0)
        private set
    var currentName by mutableStateOf("")
        private set
    var statusText by mutableStateOf("")
        private set
    var lastSearchCompleted by mutableStateOf(false)
        private set
    var cachedCount by mutableLongStateOf(0L)
        private set
    var message by mutableStateOf<String?>(null)
        private set

    /** The result currently opened in the highlight viewer (null = main screen). */
    var viewing by mutableStateOf<ResultItem?>(null)

    val results = mutableStateListOf<ResultItem>()

    private var job: Job? = null
    private var foldersLoaded = false

    fun refresh() {
        val app = getApplication<Application>()
        hasPermission = ContextCompat.checkSelfPermission(app, permissionName) ==
            PackageManager.PERMISSION_GRANTED
        if (hasPermission && !scanning) loadFolders()
        updateCacheCount()
    }

    private fun loadFolders() {
        viewModelScope.launch {
            foldersLoading = !foldersLoaded
            val app = getApplication<Application>()
            val list = withContext(Dispatchers.IO) {
                try {
                    MediaRepo.loadFolders(app)
                } catch (t: Throwable) {
                    emptyList()
                }
            }
            folders = list
            val existing = list.map { it.bucketId }.toSet()
            val saved = prefs.getStringSet("folders", null)
            selectedIds = if (saved == null) {
                // First run: pre-select screenshot folders
                list.filter {
                    it.name.contains("screenshot", ignoreCase = true) ||
                        it.name.contains("ekrānuzņēm", ignoreCase = true)
                }.map { it.bucketId }.toSet()
            } else {
                saved.mapNotNull { it.toLongOrNull() }.filter { it in existing }.toSet()
            }
            foldersLoaded = true
            foldersLoading = false
        }
    }

    fun toggleFolder(id: Long) {
        selectedIds = if (id in selectedIds) selectedIds - id else selectedIds + id
        saveFolders()
    }

    fun selectAll() {
        selectedIds = folders.map { it.bucketId }.toSet()
        saveFolders()
    }

    fun selectNone() {
        selectedIds = emptySet()
        saveFolders()
    }

    private fun saveFolders() {
        prefs.edit().putStringSet("folders", selectedIds.map { it.toString() }.toSet()).apply()
    }

    val selectedImageCount: Int
        get() = folders.filter { it.bucketId in selectedIds }.sumOf { it.count }

    fun canSearch(): Boolean =
        !scanning && selectedIds.isNotEmpty() &&
            !SearchQuery(queryText, mode, ignoreAccents).isEmpty

    fun startSearch() {
        if (!canSearch()) return
        val query = SearchQuery(queryText, mode, ignoreAccents)
        prefs.edit()
            .putString("query", queryText)
            .putString("mode", mode.name)
            .putBoolean("accents", ignoreAccents)
            .apply()

        results.clear()
        total = 0
        done = 0
        errors = 0
        statusText = ""
        lastSearchCompleted = false
        currentName = "Preparing image list…"
        scanning = true

        val app = getApplication<Application>()
        val ids = selectedIds
        val started = System.currentTimeMillis()

        job = viewModelScope.launch {
            var engine: OcrEngine? = null
            var cancelled = false
            var failure: String? = null
            try {
                val images = withContext(Dispatchers.IO) { MediaRepo.loadImages(app, ids) }
                total = images.size
                for (img in images) {
                    ensureActive()
                    currentName = img.name
                    val outcome = withContext(Dispatchers.Default) {
                        try {
                            var data = cache.get(img.id, img.modifiedSec, img.size)
                            if (data == null) {
                                val e = engine ?: OcrEngine().also { engine = it }
                                val ocr = e.read(app, img.uri)
                                data = CachedOcr(ocr.width, ocr.height, ocr.text, OcrCodec.encode(ocr.lines))
                                cache.put(img.id, img.modifiedSec, img.size, data)
                            }
                            val m = query.match(data.text)
                            if (m == null) {
                                Outcome(null, false)
                            } else {
                                val boxes = Highlighter.boxes(OcrCodec.decode(data.lines), query)
                                Outcome(
                                    ResultItem(
                                        id = img.id,
                                        uri = img.uri,
                                        hit = Hit(img.fullPath, img.name, img.folder, img.createdMillis, m.terms, m.snippet),
                                        imageWidth = data.width,
                                        imageHeight = data.height,
                                        boxes = boxes,
                                    ),
                                    false,
                                )
                            }
                        } catch (ce: CancellationException) {
                            throw ce
                        } catch (t: Throwable) {
                            // Damaged or unreadable file, out of memory, etc. — skip it and continue
                            Outcome(null, true)
                        }
                    }
                    if (outcome.error) errors++
                    outcome.item?.let { results.add(it) }
                    done++
                }
            } catch (ce: CancellationException) {
                cancelled = true
                throw ce
            } catch (t: Throwable) {
                failure = t.message ?: t.javaClass.simpleName
            } finally {
                engine?.close()
                val secs = (System.currentTimeMillis() - started) / 1000
                val err = if (errors > 0) " Unreadable: $errors." else ""
                statusText = when {
                    cancelled -> "Cancelled. Checked $done of $total, found ${results.size}.$err"
                    failure != null -> "Error: $failure"
                    else -> "Done: checked $done images, found ${results.size} (${secs} s).$err"
                }
                lastSearchCompleted = !cancelled && failure == null
                currentName = ""
                scanning = false
                updateCacheCount()
            }
        }
    }

    fun cancel() {
        if (scanning) {
            currentName = "Cancelling…"
            job?.cancel()
        }
    }

    fun copyToClipboard() {
        val app = getApplication<Application>()
        try {
            val text = Export.clipboard(results.map { it.hit })
            val cm = app.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("Search results", text))
            message = "Copied ${results.size} results"
        } catch (t: Throwable) {
            message = "Could not copy: ${t.message}"
        }
    }

    fun exportCsv(target: Uri) {
        val app = getApplication<Application>()
        val hits = results.map { it.hit }
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    val out = app.contentResolver.openOutputStream(target)
                        ?: throw IllegalStateException("Cannot create file")
                    out.use {
                        it.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte())) // UTF-8 BOM for Excel
                        it.write(Export.csv(hits).toByteArray(Charsets.UTF_8))
                    }
                    true
                } catch (t: Throwable) {
                    false
                }
            }
            message = if (ok) "CSV saved (${hits.size} rows)" else "Could not save CSV"
        }
    }

    fun clearCache() {
        if (scanning) return
        viewModelScope.launch {
            withContext(Dispatchers.IO) { cache.clear() }
            updateCacheCount()
            message = "Saved text deleted"
        }
    }

    private fun updateCacheCount() {
        viewModelScope.launch {
            cachedCount = withContext(Dispatchers.IO) {
                try {
                    cache.count()
                } catch (t: Throwable) {
                    0L
                }
            }
        }
    }

    fun showMessage(text: String) {
        message = text
    }

    fun consumeMessage() {
        message = null
    }

    override fun onCleared() {
        job?.cancel()
        cache.close()
        super.onCleared()
    }
}
