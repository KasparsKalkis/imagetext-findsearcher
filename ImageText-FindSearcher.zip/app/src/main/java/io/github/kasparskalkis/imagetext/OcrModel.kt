package io.github.kasparskalkis.imagetext

/** Rectangle in ORIGINAL image pixel coordinates. */
data class Box(val left: Int, val top: Int, val right: Int, val bottom: Int)

data class OcrWord(val text: String, val box: Box)

data class OcrLine(val words: List<OcrWord>) {
    /** Line text = words joined by single spaces (word offsets are computed the same way). */
    val text: String get() = words.joinToString(" ") { it.text }
}

/** Recognized text of one image, with the position of every word. */
data class OcrData(val width: Int, val height: Int, val lines: List<OcrLine>) {
    val text: String get() = lines.joinToString("\n") { it.text }
}

/** Compact text format for storing word positions in the database. */
object OcrCodec {
    private const val LINE_SEP = '\u001E'
    private const val WORD_SEP = '\u001F'

    fun encode(lines: List<OcrLine>): String {
        val sb = StringBuilder()
        lines.forEachIndexed { li, line ->
            if (li > 0) sb.append(LINE_SEP)
            line.words.forEachIndexed { wi, w ->
                if (wi > 0) sb.append(WORD_SEP)
                val b = w.box
                sb.append(b.left).append(',').append(b.top).append(',')
                    .append(b.right).append(',').append(b.bottom).append(',')
                    .append(clean(w.text))
            }
        }
        return sb.toString()
    }

    fun decode(s: String): List<OcrLine> {
        if (s.isEmpty()) return emptyList()
        val out = ArrayList<OcrLine>()
        for (lineStr in s.split(LINE_SEP)) {
            val words = ArrayList<OcrWord>()
            for (wStr in lineStr.split(WORD_SEP)) {
                val p = wStr.split(',', limit = 5)
                if (p.size < 5) continue
                val l = p[0].toIntOrNull() ?: continue
                val t = p[1].toIntOrNull() ?: continue
                val r = p[2].toIntOrNull() ?: continue
                val b = p[3].toIntOrNull() ?: continue
                words.add(OcrWord(p[4], Box(l, t, r, b)))
            }
            if (words.isNotEmpty()) out.add(OcrLine(words))
        }
        return out
    }

    private fun clean(t: String): String =
        t.replace(LINE_SEP, ' ').replace(WORD_SEP, ' ').replace('\n', ' ').replace('\r', ' ')
}

/** Finds the rectangles to draw around the matched words. */
object Highlighter {

    fun boxes(lines: List<OcrLine>, query: SearchQuery): List<Box> {
        val terms = query.normalizedTerms
        if (terms.isEmpty()) return emptyList()
        val result = ArrayList<Box>()
        for (line in lines) {
            if (line.words.isEmpty()) continue
            // Character range of every word inside the line text
            val starts = IntArray(line.words.size)
            val ends = IntArray(line.words.size)
            var pos = 0
            line.words.forEachIndexed { i, w ->
                starts[i] = pos
                ends[i] = pos + w.text.length
                pos = ends[i] + 1
            }
            val norm = SearchQuery.normalize(line.text, query.ignoreAccents)
            for (term in terms) {
                var idx = norm.indexOf(term)
                while (idx >= 0) {
                    val endIdx = idx + term.length
                    var l = Int.MAX_VALUE
                    var t = Int.MAX_VALUE
                    var r = Int.MIN_VALUE
                    var b = Int.MIN_VALUE
                    for (i in line.words.indices) {
                        if (starts[i] < endIdx && ends[i] > idx) {
                            val bx = line.words[i].box
                            l = minOf(l, bx.left); t = minOf(t, bx.top)
                            r = maxOf(r, bx.right); b = maxOf(b, bx.bottom)
                        }
                    }
                    if (l != Int.MAX_VALUE) result.add(Box(l, t, r, b))
                    idx = norm.indexOf(term, idx + maxOf(1, term.length))
                }
            }
        }
        return result.distinct()
    }
}
