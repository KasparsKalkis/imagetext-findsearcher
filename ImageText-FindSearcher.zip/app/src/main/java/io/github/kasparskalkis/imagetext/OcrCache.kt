package io.github.kasparskalkis.imagetext

import android.content.ContentValues
import android.content.Context
import android.database.DatabaseUtils
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class CachedOcr(val width: Int, val height: Int, val text: String, val lines: String)

/**
 * The app's PRIVATE database of already recognized text, so an image is read only once.
 * Stored only inside the app's own storage; removed when the app is uninstalled.
 * If an image changes (different size or date), its text is recognized again.
 */
class OcrCache(context: Context) : SQLiteOpenHelper(context, "ocr_cache.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE ocr (id INTEGER PRIMARY KEY, modified INTEGER NOT NULL, " +
                "size INTEGER NOT NULL, width INTEGER NOT NULL, height INTEGER NOT NULL, " +
                "text TEXT NOT NULL, lines TEXT NOT NULL)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS ocr")
        onCreate(db)
    }

    fun get(id: Long, modified: Long, size: Long): CachedOcr? =
        readableDatabase.rawQuery(
            "SELECT width, height, text, lines FROM ocr WHERE id = ? AND modified = ? AND size = ?",
            arrayOf(id.toString(), modified.toString(), size.toString()),
        ).use { c ->
            if (c.moveToFirst()) CachedOcr(c.getInt(0), c.getInt(1), c.getString(2), c.getString(3)) else null
        }

    fun put(id: Long, modified: Long, size: Long, data: CachedOcr) {
        val cv = ContentValues()
        cv.put("id", id)
        cv.put("modified", modified)
        cv.put("size", size)
        cv.put("width", data.width)
        cv.put("height", data.height)
        cv.put("text", data.text)
        cv.put("lines", data.lines)
        writableDatabase.insertWithOnConflict("ocr", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun count(): Long = DatabaseUtils.queryNumEntries(readableDatabase, "ocr")

    fun clear() {
        writableDatabase.delete("ocr", null, null)
    }
}
