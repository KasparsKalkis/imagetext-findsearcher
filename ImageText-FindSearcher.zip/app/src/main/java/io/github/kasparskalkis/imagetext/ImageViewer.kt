package io.github.kasparskalkis.imagetext

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapRegionDecoder
import android.graphics.Rect
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.IOException

private val HighlightFill = Color(0x55FFEB3B)
private val HighlightStroke = Color(0xFFFF5722)

/**
 * Shows the found image inside the app with a frame around every matched word.
 * Long screenshots scroll vertically and the view jumps to the first match.
 */
@Composable
fun ImageViewer(item: ResultItem, onClose: () -> Unit, onOpenInGallery: () -> Unit) {
    BackHandler { onClose() }
    val context = LocalContext.current

    val tiles by produceState<List<ImageBitmap>?>(initialValue = null, item.uri) {
        value = withContext(Dispatchers.IO) {
            try {
                loadTiles(context, item.uri)
            } catch (t: Throwable) {
                emptyList()
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp),
        ) {
            TextButton(onClick = onClose) { Text("‹ Back") }
            Text(
                item.hit.fileName,
                style = MaterialTheme.typography.titleSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            TextButton(onClick = onOpenInGallery) { Text("Gallery") }
        }
        Text(
            if (item.boxes.isNotEmpty()) {
                "Matches marked: ${item.boxes.size} · " + item.hit.matched.joinToString(", ")
            } else {
                "Text was found, but its exact position could not be marked (e.g. a phrase split across lines)."
            },
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
        )
        HorizontalDivider()

        val t = tiles
        when {
            t == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            t.isEmpty() -> Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                Text("Could not display this image. Try “Gallery”.")
            }
            else -> HighlightedImage(item, t)
        }
    }
}

@Composable
private fun HighlightedImage(item: ResultItem, tiles: List<ImageBitmap>) {
    val scroll = rememberScrollState()
    var widthPx by remember { mutableIntStateOf(0) }

    Column(Modifier.fillMaxSize().verticalScroll(scroll)) {
        Box(Modifier.fillMaxWidth().onSizeChanged { widthPx = it.width }) {
            Column(verticalArrangement = Arrangement.Top) {
                for (tile in tiles) {
                    Image(
                        bitmap = tile,
                        contentDescription = null,
                        contentScale = ContentScale.FillWidth,
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(tile.width.toFloat() / tile.height.toFloat()),
                    )
                }
            }
            if (item.imageWidth > 0 && item.boxes.isNotEmpty()) {
                Canvas(Modifier.matchParentSize()) {
                    val s = size.width / item.imageWidth.toFloat()
                    val pad = 4.dp.toPx()
                    val stroke = 2.5.dp.toPx()
                    for (b in item.boxes) {
                        val topLeft = Offset(b.left * s - pad, b.top * s - pad)
                        val sz = Size((b.right - b.left) * s + 2 * pad, (b.bottom - b.top) * s + 2 * pad)
                        drawRect(HighlightFill, topLeft, sz)
                        drawRect(HighlightStroke, topLeft, sz, style = Stroke(width = stroke))
                    }
                }
            }
        }
    }

    // Jump to the first match (useful for long screenshots)
    LaunchedEffect(widthPx, tiles) {
        if (widthPx > 0 && item.imageWidth > 0 && item.boxes.isNotEmpty()) {
            val s = widthPx.toFloat() / item.imageWidth.toFloat()
            val firstTop = item.boxes.minOf { it.top }
            val target = (firstTop * s - 300f).toInt().coerceAtLeast(0)
            if (target > 0) {
                withTimeoutOrNull(2000) { snapshotFlow { scroll.maxValue }.first { it > 0 } }
                scroll.scrollTo(target.coerceAtMost(scroll.maxValue))
            }
        }
    }
}

/**
 * Decodes the image for display in horizontal strips (tiles), so that very long
 * screenshots do not exceed graphics limits. Read-only.
 */
private fun loadTiles(ctx: Context, uri: Uri): List<ImageBitmap> {
    val cr = ctx.contentResolver
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    (cr.openInputStream(uri) ?: throw IOException("Cannot open file")).use {
        BitmapFactory.decodeStream(it, null, bounds)
    }
    val w = bounds.outWidth
    val h = bounds.outHeight
    if (w <= 0 || h <= 0) return emptyList()

    var sample = 1
    while (w / sample > 1440 || (w.toLong() / sample) * (h.toLong() / sample) * 2L > 48_000_000L) {
        sample *= 2
    }
    val opts = BitmapFactory.Options().apply {
        inSampleSize = sample
        inPreferredConfig = Bitmap.Config.RGB_565
    }

    val tiles = ArrayList<ImageBitmap>()
    try {
        (cr.openInputStream(uri) ?: throw IOException("Cannot open file")).use { input ->
            @Suppress("DEPRECATION")
            val decoder = BitmapRegionDecoder.newInstance(input, false) ?: throw IOException("No decoder")
            try {
                val tileH = 2048 * sample
                var top = 0
                while (top < h) {
                    val bottom = minOf(h, top + tileH)
                    decoder.decodeRegion(Rect(0, top, w, bottom), opts)?.let { tiles.add(it.asImageBitmap()) }
                    top = bottom
                }
            } finally {
                decoder.recycle()
            }
        }
    } catch (e: IOException) {
        // Fallback for formats the region decoder does not support
        tiles.clear()
        (cr.openInputStream(uri) ?: throw IOException("Cannot open file")).use { input ->
            BitmapFactory.decodeStream(input, null, opts)?.let { tiles.add(it.asImageBitmap()) }
        }
    }
    return tiles
}
